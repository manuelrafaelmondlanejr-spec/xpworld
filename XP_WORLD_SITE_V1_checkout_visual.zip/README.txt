XP WORLD — SITE V1

Conteúdo:
- Página inicial
- Loja com produtos
- Formulário de compra (Nick + método de pagamento)
- Área de servidor
- Espaços reservados para anúncios
- Layout responsivo para telemóvel

IMPORTANTE:
Esta V1 NÃO processa pagamentos reais e NÃO entrega itens automaticamente.
Isso é proposital: primeiro testamos o site. Depois ligamos um backend, confirmação de pagamento e entrega no Minecraft.

Como testar no Termux:
1. Instale Node.js.
2. Entre na pasta do site.
3. Execute: npx serve .
4. Abra o endereço mostrado pelo comando.

Próxima fase:
- Backend Node.js
- Base de dados de pedidos
- Painel admin
- Integração de pagamento disponível em Moçambique
- Sistema de entrega/recebimento no Minecraft
- Configuração de anúncios de forma compatível com as regras da rede escolhida
